"""The BFT component."""

